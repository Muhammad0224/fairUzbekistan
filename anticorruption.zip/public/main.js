document.getElementById('UZB354').title = 'Title';
alert('asdasd');